/**
 * Vous n'avez rien a faire sur cet exercice, il a seulement pour but de vous montrer
 * le fonctionnement de la moulinette
 * 
 * Vous pouvez passer a l'exercice suivant
 * 
 */

function gettingStarted() {
  return "hello world";
}

/**
 * Comment me tester ? 
 */
console.log(gettingStarted());
//$> node ./gettingStarted.js


/**
 * Ne pas modifier l'export
 */

module.exports = gettingStarted;